cp rtkpost_qt ../../../RTKLIB_bin/bin
