cp rtknavi_qt ../../../RTKLIB_bin/bin
