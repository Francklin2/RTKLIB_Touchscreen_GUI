#!/bin/bash

# Install RTKBASE folder from github
cd $HOME
git clone https://github.com/Francklin2/RTKLIB_Touchscreen_GUI.git
